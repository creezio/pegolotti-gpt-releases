const html = `<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mon Pegolotti</title><style>*{box-sizing:border-box}body{margin:0;background:#f5f7f8;color:#0b2030;font:16px Arial,sans-serif}aside{position:fixed;inset:0 auto 0 0;width:224px;background:#0b2030;padding:32px;color:white}aside b{font-size:26px;color:#ffc400}main{margin-left:224px;padding:64px;max-width:1100px}.card{background:white;border:1px solid #dde4e8;border-radius:10px;padding:32px;margin-top:28px}.tag{display:inline-block;background:#fff3bd;padding:8px 12px;border-radius:8px}h1{font-size:42px;letter-spacing:-1px}p{line-height:1.7;color:#526775}@media(max-width:650px){aside{position:static;width:auto;padding:20px}main{margin:0;padding:24px}}</style><aside><b>Pegolotti</b><p style="color:#bdcbd2">Votre espace personnel</p></aside><main><span class="tag">Votre socle est prêt</span><h1>Bienvenue chez vous.</h1><p>Cet espace appartient à votre compte ChatGPT. Vous pourrez y installer votre application Pegolotti et la faire évoluer depuis Pegolotti GPT.</p><section class="card"><h2>Votre application arrive</h2><p>Le harness et le plugin privé sont préparés. L’application métier sera installée lorsqu’une version sera disponible.</p></section></main></html>`;
const tools = [{ name: 'pegolotti_environment_status', description: 'Lire le statut du socle personnel Pegolotti.', inputSchema: { type: 'object', properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, destructiveHint: false } }];
export default { async fetch(request) {
  const url = new URL(request.url);
  if (url.pathname !== '/mcp') return new Response(html, { headers: { 'content-type': 'text/html; charset=utf-8', 'content-security-policy': "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'self'", 'x-content-type-options': 'nosniff' } });
  if (request.method !== 'POST') return new Response('POST required', { status: 405 });
  let call; try { const text = await request.text(); if (text.length > 4096) throw new Error(); call = JSON.parse(text); } catch { return Response.json({ error: 'Invalid MCP request' }, { status: 400 }); }
  let result;
  if (call.method === 'server/discover') result = { supportedVersions: ['2026-07-28'], capabilities: { tools: {} } };
  else if (call.method === 'initialize') result = { protocolVersion: '2026-07-28', serverInfo: { name: 'pegolotti-restaurant', version: '0.1.0' }, capabilities: { tools: {} } };
  else if (call.method === 'notifications/initialized') return new Response(null, { status: 202 });
  else if (call.method === 'tools/list') result = { tools };
  else if (call.method === 'tools/call') {
    const authorized = !!request.headers.get('oai-authenticated-user-id');
    const valid = call.params?.name === tools[0].name && call.params.arguments && !Array.isArray(call.params.arguments) && !Object.keys(call.params.arguments).length;
    result = !authorized || !valid ? { isError: true, content: [{ type: 'text', text: 'Accès ou outil non autorisé.' }] } : { content: [{ type: 'text', text: JSON.stringify({ harness: 'Pegolotti GPT', environment: 'ready', application: 'unavailable', businessFeatures: [] }) }], structuredContent: { environment: 'ready', application: 'unavailable' } };
  } else return Response.json({ jsonrpc: '2.0', id: call.id ?? null, error: { code: -32601, message: 'Method not found' } });
  return Response.json({ jsonrpc: '2.0', id: call.id ?? null, result });
} };
