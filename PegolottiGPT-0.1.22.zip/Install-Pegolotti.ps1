[CmdletBinding()]
param([string]$PackageDirectory,[switch]$StartAtLogin,[switch]$Launch)
$ErrorActionPreference='Stop'
if(-not $PackageDirectory){if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'PegolottiGpt.exe')){$PackageDirectory=$PSScriptRoot}else{$PackageDirectory=Join-Path $PSScriptRoot '..\native\build'}}
$source=[IO.Path]::GetFullPath($PackageDirectory).TrimEnd('\')
$destination=Join-Path $env:LOCALAPPDATA 'Programs\Pegolotti\GPT'
if((Get-PSDrive -Name ([IO.Path]::GetPathRoot($destination).Substring(0,1))).Free -lt 20GB){throw 'Au moins 20 Gio libres requis avant installation.'}
foreach($root in @($source,$destination)){$cursor=[IO.Path]::GetFullPath($root);while($cursor){if((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Lien ou jonction refusé.'};$cursor=Split-Path -Parent $cursor}}
foreach($name in @('PegolottiGpt.exe','CreezioRelay.exe','SwitcherCodexBridge.exe','SwitcherLauncher.exe','switcher-update.json')){if(-not(Test-Path -LiteralPath (Join-Path $source $name))){throw "Paquet incomplet : $name"}}
$process=Start-Process -FilePath (Join-Path $source 'SwitcherLauncher.exe') -ArgumentList @('--install-from',('"'+$source+'"')) -WindowStyle Hidden -Wait -PassThru
if($process.ExitCode -ne 0){throw 'La validation ou installation versionnée a échoué. Les comptes et la version active sont conservés.'}
$registryPath='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
if(-not $StartAtLogin){Remove-ItemProperty -Path $registryPath -Name 'Pegolotti GPT' -ErrorAction SilentlyContinue}
if($Launch){Start-Process -FilePath (Join-Path $destination 'Pegolotti.exe') -WindowStyle Hidden}
[pscustomobject]@{Installed=$destination;Data=(Join-Path $env:LOCALAPPDATA 'Pegolotti\GPT');StartAtLogin=[bool]$StartAtLogin}
