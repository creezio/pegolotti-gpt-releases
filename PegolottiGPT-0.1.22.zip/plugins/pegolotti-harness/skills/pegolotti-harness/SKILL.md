---
name: pegolotti-harness
description: Configurer les plugins et préparer, installer ou faire évoluer l'application du restaurateur dans son environnement Pegolotti GPT.
---

Pegolotti GPT est un harness. Aucune fonctionnalité métier Pegolotti n'est incluse dans ce socle.

Lire `harness_status` et `application_status` avant d'affirmer qu'une application, un plugin ou un déploiement est prêt. Installation locale, chargement MCP, installation dans le compte et connexion OAuth sont des états distincts.

Utiliser uniquement le compte permanent de ce restaurant et son espace de travail autorisé. Ne pas déléguer vers d'autres comptes, rechercher une installation Switcher ni lire ses profils. Ne jamais afficher de tokens ou de clés.

Lorsque l'application est disponible, suivre le manifeste de version et les workflows de contrôle/publication du harness. Conserver la base et les personnalisations, vérifier le déploiement natif, et conserver la version permettant une restauration. Ne jamais présenter l'exemple technique comme l'application métier.

Pour Sites et les autres plugins, utiliser les outils et skills officiels réellement découverts dans ce compte. Une connexion interactive officielle peut être nécessaire ; ne pas fabriquer un état connecté. Un résultat incertain d'écriture doit être réconcilié avec la ressource avant tout nouvel envoi.

Le contrôle Windows ne devient disponible qu'après confirmation de la capacité native. Respecter les autorisations et demandes d'arrêt natives ; ne pas utiliser le shell pour contourner un refus de contrôle.
