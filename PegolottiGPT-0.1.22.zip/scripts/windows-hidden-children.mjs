import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';

// Loaded only through the Sites helper's private NODE_OPTIONS. The official
// helper and its Node descendants keep their original code and command arrays.
// No environment of the Windows host, browser or Codex process is changed.
if (process.platform === 'win32') {
  const original = childProcess.spawn;
  childProcess.spawn = function spawnHidden(command, args, options) {
    if (!Array.isArray(args)) { options = args; args = []; }
    return Reflect.apply(original, this, [command, args, { ...options, windowsHide: true }]);
  };
  // Sites imports the named ESM spawn export rather than the default object.
  syncBuiltinESMExports();
}
