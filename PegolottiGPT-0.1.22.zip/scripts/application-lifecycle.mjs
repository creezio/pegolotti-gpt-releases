import { readFile, writeFile, rename, mkdir, lstat } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { provisionRestaurant, unwrapNative, ProvisioningError } from './provision-restaurant.mjs';

const sha256 = value => createHash('sha256').update(value).digest('hex');
const reserved = /^\.(git|openai|pegolotti)(\/|$)|^node_modules(\/|$)|^\.env(?:\.|$)|^(dist|build|\.wrangler)(\/|$)/i;
const versionPattern = /^[a-zA-Z0-9][a-zA-Z0-9._+-]{0,99}$/;
const resourcePattern = /^[A-Za-z0-9_-]{1,200}$/;
const windowsDevice = /^(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³]|conin\$|conout\$|clock\$)(?:\.|$)/i;
const canonicalPath = value => value.normalize('NFC').toUpperCase();
const runFile = promisify(execFile);
export function releasePath(value) {
  if (typeof value !== 'string' || !value || value.includes('\\') || /[<>:"|?*\u0000-\u001f]/.test(value) || value.split('/').some(part => !part || part === '.' || part === '..' || /[.\s]$/.test(part) || windowsDevice.test(part) || /^\.(?:git|openai|pegolotti|wrangler)$|^node_modules$|^\.env(?:\.|$)/i.test(part)) || path.posix.isAbsolute(value) || reserved.test(value)) throw new ProvisioningError('INVALID_RELEASE_PATH', 'Le paquet contient un chemin réservé ou invalide.');
  return value;
}
function within(root, target, allowRoot = false) {
  const relative = path.relative(path.resolve(root), path.resolve(target));
  if ((!allowRoot && !relative) || relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) throw new ProvisioningError('INVALID_RELEASE_PATH', 'Le chemin sort du dossier autorisé.');
  return target;
}
async function rejectLinks(absolute) {
  const full = path.resolve(absolute), parsed = path.parse(full); let current = parsed.root;
  for (const part of full.slice(parsed.root.length).split(path.sep)) { current = path.join(current, part); try { if ((await lstat(current)).isSymbolicLink()) throw new ProvisioningError('LINK_REJECTED', 'Les liens et jonctions ne sont pas acceptés dans les sources ou journaux.'); } catch (error) { if (error.code !== 'ENOENT') throw error; } }
}
async function optionalFile(file) { await rejectLinks(file); try { return await readFile(file); } catch (error) { if (error.code === 'ENOENT') return null; throw error; } }
async function jsonFile(file, fallback = null) { const bytes = await optionalFile(file); return bytes ? JSON.parse(bytes.toString('utf8')) : fallback; }
async function atomic(file, content) { await rejectLinks(file); await rejectLinks(file + '.pegolotti-tmp'); await mkdir(path.dirname(file), { recursive: true }); await writeFile(file + '.pegolotti-tmp', content, { mode: 0o600 }); await rename(file + '.pegolotti-tmp', file); }
async function immutableBackup(file, content, expectedHash) {
  const old = await optionalFile(file);
  // A process crash while writing a temporary backup leaves the original
  // target intact. Only complete backups are admitted under their final name.
  if (!old) await atomic(file, content);
  if (sha256(await readFile(file)) !== expectedHash) throw new ProvisioningError('BACKUP_CONFLICT', 'La sauvegarde originale est incompatible. Elle reste conservée.');
}
function checkApplicationState(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || value.version && !versionPattern.test(value.version) || value.releaseId && !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,99}$/.test(value.releaseId)) throw new ProvisioningError('INVALID_APPLICATION_STATE', 'Le journal de l’application doit être vérifié avant reprise.');
  for (const [relative, hash] of Object.entries(value.files || {})) if (releasePath(relative) !== relative || !/^[a-f0-9]{64}$/.test(hash)) throw new ProvisioningError('INVALID_APPLICATION_STATE', 'Les empreintes de l’application sont invalides.');
}
async function workspacePaths(config) {
  if (typeof config.workspace !== 'string' || !config.workspace) throw new ProvisioningError('WORKSPACE_REQUIRED', 'Le workspace du restaurant est requis.');
  const workspace = path.resolve(config.workspace); await rejectLinks(workspace);
  return { workspace, targetRoot: within(workspace, path.join(workspace, 'pegolotti-site')), metadataRoot: within(workspace, path.join(workspace, '.pegolotti')) };
}
async function requireReconciledSources(config) {
  const { metadataRoot } = await workspacePaths(config), journal = await jsonFile(path.join(metadataRoot, 'provision.json'), {});
  if (journal.sourceReconciliationRequired) throw new ProvisioningError('SOURCE_RECONCILIATION_REQUIRED', 'Le Site a été restauré. Réconciliez explicitement ses sources locales avant une installation ou publication.');
}
function verifiedTemplateFiles(baseline) {
  if (baseline === undefined) return {};
  if (!baseline || baseline.schemaVersion !== 1 || baseline.source !== 'bundled-restaurant-template' || !baseline.files || typeof baseline.files !== 'object' || Array.isArray(baseline.files) || !/^[a-f0-9]{64}$/.test(baseline.fingerprint || '')) throw new ProvisioningError('INVALID_TEMPLATE_BASELINE', 'Le relevé du socle initial doit être vérifié avant son remplacement.');
  const entries = Object.entries(baseline.files), names = new Set();
  for (const [relative, hash] of entries) {
    const name = canonicalPath(releasePath(relative));
    if (names.has(name) || !/^[a-f0-9]{64}$/.test(hash)) throw new ProvisioningError('INVALID_TEMPLATE_BASELINE', 'Le relevé du socle initial contient une empreinte ou un chemin invalide.');
    names.add(name);
  }
  const fingerprint = sha256(JSON.stringify(entries.sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0)));
  if (fingerprint !== baseline.fingerprint) throw new ProvisioningError('INVALID_TEMPLATE_BASELINE', 'Le relevé du socle initial a changé. Aucun fichier n’a été remplacé.');
  return baseline.files;
}
export async function installRelease(config, adapters = {}) {
  if (!config.releaseManifestPath) return { state: 'unavailable', detail: 'Aucune version de l’application n’est disponible.' };
  await requireReconciledSources(config);
  const manifestPath = path.resolve(config.releaseManifestPath); await rejectLinks(manifestPath);
  let manifest; try { manifest = JSON.parse(await readFile(manifestPath, 'utf8')); } catch (error) { if (error.code === 'ENOENT') return { state: 'unavailable' }; throw error; }
  if (manifest.schemaVersion !== 1 || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,99}$/.test(manifest.id || '') || !/^[a-zA-Z0-9][a-zA-Z0-9._+-]{0,99}$/.test(manifest.version || '') || !manifest.sourceDirectory || !Array.isArray(manifest.files) || !manifest.files.length || manifest.files.length > 2000 || config.releaseId && config.releaseId !== manifest.id) throw new ProvisioningError('INVALID_RELEASE', 'Le manifeste de version n’est pas reconnu.');
  if (manifest.sourceDirectory !== '.') releasePath(manifest.sourceDirectory);
  const packageRoot = path.dirname(manifestPath), sourceRoot = within(packageRoot, path.resolve(packageRoot, manifest.sourceDirectory), true); await rejectLinks(sourceRoot);
  const { targetRoot, metadataRoot } = await workspacePaths(config);
  const metadata = path.join(metadataRoot, 'application.json'), installJournal = path.join(metadataRoot, 'application-install.json');
  let previous = await jsonFile(metadata, {}); checkApplicationState(previous);
  // Legacy journals without a recorded baseline have no trusted overwrite
  // allowance. Never reconstruct one by trusting whatever is on disk today.
  const templateFiles = verifiedTemplateFiles((await jsonFile(path.join(metadataRoot, 'provision.json'), {})).templateBaseline);
  const staged = [], paths = new Set(), conflicts = []; let bytes = 0;
  for (const entry of manifest.files) {
    const relative = releasePath(entry.path), folded = canonicalPath(relative);
    if (paths.has(folded) || [...paths].some(old => old.startsWith(`${folded}/`) || folded.startsWith(`${old}/`)) || !/^[a-f0-9]{64}$/.test(entry.sha256 || '')) throw new ProvisioningError('INVALID_RELEASE', 'Le manifeste contient un doublon Windows, un conflit de chemin ou une empreinte invalide.'); paths.add(folded);
    const source = within(sourceRoot, path.join(sourceRoot, relative)); await rejectLinks(source); await rejectLinks(path.join(targetRoot, relative));
    const info = await lstat(source); bytes += info.size;
    if (!info.isFile() || bytes > 64 * 1024 * 1024) throw new ProvisioningError('RELEASE_INTEGRITY', 'Le paquet dépasse la taille autorisée ou contient un objet non régulier.');
    const content = await readFile(source);
    if (sha256(content) !== entry.sha256) throw new ProvisioningError('RELEASE_INTEGRITY', 'L’intégrité du paquet d’application n’est pas confirmée.');
    const current = await optionalFile(path.join(targetRoot, relative)); const currentHash = current ? sha256(current) : null;
    staged.push({ relative, content, current, currentHash, hash: entry.sha256 });
  }
  const releaseFingerprint = sha256(JSON.stringify([manifest.id, manifest.version, staged.map(entry => [entry.relative, entry.hash])])), pending = await jsonFile(installJournal);
  let transaction;
  if (pending && pending.state !== 'committed') {
    if (pending.releaseFingerprint !== releaseFingerprint || config.operationId && pending.operationId && config.operationId !== pending.operationId) throw new ProvisioningError('INSTALL_IN_PROGRESS', 'Reprenez l’installation interrompue avant de changer de version.');
    checkApplicationState(pending.previousState); previous = pending.previousState;
    if (!/^[a-f0-9]{32}$/.test(pending.transactionId || '') || !Array.isArray(pending.files) || pending.files.length !== staged.length || pending.files.some((entry, index) => entry.path !== staged[index].relative || entry.afterHash !== staged[index].hash || entry.beforeHash !== null && !/^[a-f0-9]{64}$/.test(entry.beforeHash))) throw new ProvisioningError('INVALID_APPLICATION_STATE', 'Le journal de reprise est incohérent.');
    transaction = pending;
  } else {
    const sameVersion = previous.releaseId === manifest.id && previous.version === manifest.version;
    const sameFiles = staged.length === Object.keys(previous.files || {}).length && staged.every(entry => previous.files?.[entry.relative] === entry.hash);
    if ((previous.releaseFingerprint === releaseFingerprint || sameVersion && sameFiles) && staged.every(entry => entry.currentHash === entry.hash)) return previous;
    if (sameVersion && !sameFiles) throw new ProvisioningError('RELEASE_VERSION_CONFLICT', 'Une version publiée est immuable. Le paquet doit déclarer une nouvelle version.');
    for (const entry of staged) {
      const previousHash = previous.files?.[entry.relative];
      const intactTemplate = previousHash === undefined && templateFiles[entry.relative] === entry.currentHash;
      if (entry.current && entry.currentHash !== entry.hash && entry.currentHash !== previousHash && !intactTemplate) conflicts.push(entry.relative);
    }
    transaction = { schemaVersion: 1, transactionId: sha256(`${releaseFingerprint}\n${JSON.stringify(previous)}\n${config.operationId || ''}`).slice(0, 32), operationId: config.operationId || null, releaseFingerprint, state: 'preparing-backups', previousState: previous,
      files: staged.map(entry => ({ path: entry.relative, beforeHash: entry.currentHash, afterHash: entry.hash })), createdAt: new Date().toISOString() };
  }
  if (conflicts.length) return { state: 'conflict', releaseId: manifest.id, version: manifest.version, conflicts };
  const backup = within(metadataRoot, path.join(metadataRoot, 'application-versions', transaction.transactionId));
  await atomic(installJournal, JSON.stringify(transaction, null, 2));
  // Every original is secured before any target changes. Backups are created
  // once and verified on resume; a newer target can never replace an original.
  for (let index = 0; index < staged.length; index++) {
    const entry = staged[index], plan = transaction.files[index]; if (plan.beforeHash === null) continue;
    const destination = path.join(backup, 'sources', entry.relative), stored = await optionalFile(destination);
    if (!stored && entry.currentHash !== plan.beforeHash) throw new ProvisioningError('BACKUP_MISSING', 'La source originale doit être récupérée avant reprise ; aucun fichier n’a été écrasé.');
    await immutableBackup(destination, stored || entry.current, plan.beforeHash);
  }
  transaction.state = 'applying'; await atomic(installJournal, JSON.stringify(transaction, null, 2));
  for (let index = 0; index < staged.length; index++) {
    const entry = staged[index], plan = transaction.files[index], target = path.join(targetRoot, entry.relative), current = await optionalFile(target), currentHash = current ? sha256(current) : null;
    if (currentHash !== entry.hash && currentHash !== plan.beforeHash) throw new ProvisioningError('INSTALL_CONFLICT', 'Une source personnalisée a changé pendant l’installation. Elle reste conservée.');
    if (currentHash !== entry.hash) { await atomic(target, entry.content); await adapters.afterFileWrite?.(index, entry.relative); }
  }
  const alreadyCommitted = await jsonFile(metadata, {});
  const result = alreadyCommitted.transactionId === transaction.transactionId ? alreadyCommitted : { schemaVersion: 1, state: 'installed', releaseId: manifest.id, version: manifest.version, releaseFingerprint, transactionId: transaction.transactionId, files: Object.fromEntries(staged.map(entry => [entry.relative, entry.hash])), installedAt: new Date().toISOString(), previousVersion: previous.version || null, backupId: transaction.transactionId };
  await atomic(metadata, JSON.stringify(result, null, 2));
  await adapters.afterMetadataWrite?.(result);
  transaction.state = 'committed'; transaction.completedAt = result.installedAt; await atomic(installJournal, JSON.stringify(transaction, null, 2)); return result;
}
async function restoreRelease(config, adapters) {
  if (!resourcePattern.test(config.versionId || '') || !/^[a-f0-9]{32}$/.test(config.operationId || '')) throw new ProvisioningError('VERSION_REQUIRED', 'Une version sauvegardée et un identifiant d’opération sont requis.');
  const { metadataRoot } = await workspacePaths(config), journalPath = path.join(metadataRoot, 'provision.json'), recordPath = path.join(metadataRoot, 'application-restore.json');
  const journal = await jsonFile(journalPath);
  const version = journal?.versions?.find(value => value.id === config.versionId);
  if (!resourcePattern.test(journal?.projectId || '') || !version) throw new ProvisioningError('UNKNOWN_VERSION', 'Cette version n’appartient pas à l’historique de ce Site.');
  if (!adapters.gateway) throw new ProvisioningError('NATIVE_REQUIRED', 'Le transport natif est requis pour restaurer la version.');
  let record = await jsonFile(recordPath);
  if (record && record.operationId === config.operationId && (record.projectId !== journal.projectId || record.versionId !== config.versionId)) throw new ProvisioningError('RESTORE_CONFLICT', 'Cet identifiant de restauration correspond à une autre version.');
  if (record && record.operationId !== config.operationId && !['restored', 'failed'].includes(record.state)) throw new ProvisioningError('RESTORE_PENDING', 'Reprenez la restauration existante avant une autre opération.');
  if (!record || record.operationId !== config.operationId) record = { schemaVersion: 1, operationId: config.operationId, projectId: journal.projectId, versionId: config.versionId, attempt: 1, state: 'starting', createdAt: new Date().toISOString(), pollCount: 0 };
  const result = () => ({ state: 'restored', deploymentId: record.deploymentId, versionId: record.versionId, siteUrl: record.siteUrl, sourceReconciliationRequired: true, detail: 'Le Site est restauré. Ses sources locales sont conservées ; une réconciliation explicite est requise avant publication.' });
  const previouslyRestored = record.state === 'restored';
  if (record.state === 'failed') { record.attempt++; record.state = 'starting'; record.deploymentId = null; record.deploymentState = null; }
  const save = async () => {
    record.updatedAt = new Date().toISOString(); await atomic(recordPath, JSON.stringify(record, null, 2));
    const current = await jsonFile(journalPath, journal);
    current.sourceReconciliationRequired = true;
    current.sourceReconciliation = { required: true, versionId: config.versionId, commitSha: version.commitSha || null, reason: 'deployment-restored-sources-preserved', deploymentConfirmed: record.state === 'restored' };
    current.restoreOperation = record; current.state = record.state === 'restored' ? 'restored' : record.state === 'failed' ? 'restore-failed' : 'restoring';
    if (record.state === 'restored') {
      current.previousDeploymentId = current.deploymentId; current.previousSavedVersionId = current.savedVersionId;
      current.deploymentId = record.deploymentId; current.deploymentState = 'succeeded'; current.savedVersionId = config.versionId;
      current.restoredVersionId = config.versionId; current.deployedCommitSha = version.commitSha || null; current.siteUrl = record.siteUrl || current.siteUrl;
    }
    await atomic(journalPath, JSON.stringify(current, null, 2));
  };
  if (previouslyRestored) {
    // Finish a crash between the restore receipt and its Site journal update.
    // A replay after later reconciliation/publication must not change it again.
    if (journal.restoreOperation?.operationId === record.operationId && journal.restoreOperation.state !== 'restored') await save();
    return result();
  }
  const inventory = unwrapNative(await adapters.gateway({ operation: 'list' })).tools || [];
  const tool = suffix => { const found = inventory.find(row => (row.name || row.Name || '').endsWith(`.${suffix}`)); if (!found) throw new ProvisioningError('MISSING_TOOL', `L’outil Sites ${suffix} n’est pas disponible.`); return found; };
  const call = async (suffix, args, id) => { const found = tool(suffix); return unwrapNative(await adapters.gateway({ operation: 'call', server: found.server || found.Server, tool: found.name || found.Name, id, arguments: args, ...(config.threadId ? { threadId: config.threadId } : {}) })); };
  if (!record.deploymentId) {
    record.requestId ||= sha256(`${journal.projectId}:${config.versionId}:restore:${config.operationId}:${record.attempt}`).slice(0, 32);
    if (record.requestAttempt !== record.attempt) { record.requestId = sha256(`${journal.projectId}:${config.versionId}:restore:${config.operationId}:${record.attempt}`).slice(0, 32); record.requestAttempt = record.attempt; }
    await save();
    const deployment = await call('deploy_private_site_version', { project_id: journal.projectId, version_id: config.versionId }, record.requestId);
    if (!deployment?.id) { record.state = 'uncertain'; await save(); throw new ProvisioningError('DEPLOYMENT_UNCONFIRMED', 'Le reçu de restauration est absent. Vérifiez l’opération native avant de reprendre.'); }
    record.deploymentId = deployment.id; record.deploymentState = deployment.status; record.siteUrl = deployment.url || journal.siteUrl; record.state = 'restoring'; await save();
  }
  for (let attempt = 0; !['succeeded', 'failed', 'cancelled'].includes(record.deploymentState) && attempt < (adapters.maxPolls ?? 30); attempt++) {
    await (adapters.delay || (ms => new Promise(resolve => setTimeout(resolve, ms))))(2000);
    record.pollCount++; await save();
    let deployment;
    try { deployment = await call('get_deployment_status', { project_id: journal.projectId, deployment_id: record.deploymentId }, sha256(`${config.operationId}:${record.deploymentId}:poll:${record.pollCount}`).slice(0, 32)); }
    catch { record.state = 'pending'; await save(); throw new ProvisioningError('RESTORE_PENDING', 'Le déploiement existe ; son état réseau reste à vérifier avec la même opération.'); }
    record.deploymentState = deployment.status; record.siteUrl = deployment.url || record.siteUrl; await save();
  }
  if (record.deploymentState === 'succeeded') { record.state = 'restored'; await save(); return result(); }
  if (['failed', 'cancelled'].includes(record.deploymentState)) { record.state = 'failed'; await save(); throw new ProvisioningError('RESTORE_FAILED', 'La restauration a échoué. Les sources et reçus sont conservés pour une nouvelle tentative.'); }
  record.state = 'pending'; await save(); throw new ProvisioningError('RESTORE_PENDING', 'La restauration est encore en cours. Reprenez la même opération pour vérifier son déploiement.');
}
async function reconcileSources(config, adapters) {
  const { metadataRoot, targetRoot } = await workspacePaths(config), journalPath = path.join(metadataRoot, 'provision.json'), journal = await jsonFile(journalPath);
  const version = journal?.versions?.find(value => value.id === config.versionId);
  if (!journal?.sourceReconciliationRequired || journal.deploymentState !== 'succeeded' || journal.restoredVersionId !== config.versionId || journal.savedVersionId !== config.versionId || !/^[a-f0-9]{40,64}$/.test(version?.commitSha || '')) throw new ProvisioningError('SOURCE_RECONCILIATION_REQUIRED', 'Terminez la restauration vérifiée avant de réconcilier ses sources.');
  await rejectLinks(targetRoot); await rejectLinks(path.join(targetRoot, '.git'));
  let proven = false;
  if (adapters.inspectSources) proven = await adapters.inspectSources({ directory: targetRoot, commitSha: version.commitSha });
  else {
    const environment = { ...process.env }; for (const key of Object.keys(environment)) if (key.startsWith('GIT_')) delete environment[key];
    const execute = args => runFile('git', ['-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=', '-c', 'core.pager=false', ...args], { cwd: targetRoot, env: environment, windowsHide: true, timeout: 15000, maxBuffer: 256 * 1024, encoding: 'utf8' });
    try {
      const top = (await execute(['rev-parse', '--show-toplevel'])).stdout.trim(), status = (await execute(['status', '--porcelain', '--untracked-files=all', '--ignored=no'])).stdout;
      if (canonicalPath(path.resolve(top)) === canonicalPath(path.resolve(targetRoot)) && !status.trim()) { await execute(['diff', '--quiet', '--no-ext-diff', '--no-textconv', version.commitSha, '--', '.']); proven = true; }
    } catch { proven = false; }
  }
  if (!proven) throw new ProvisioningError('SOURCE_RECONCILIATION_REQUIRED', 'Les sources locales diffèrent encore de la version restaurée. Aucun fichier n’a été remplacé.');
  journal.sourceReconciliationRequired = false; journal.commitSha = version.commitSha;
  journal.sourceReconciliation = { required: false, versionId: config.versionId, verifiedCommitSha: version.commitSha, verifiedAt: new Date().toISOString() };
  journal.state = journal.pluginInstalled && journal.pluginConnected ? 'ready' : 'connection-required';
  await atomic(journalPath, JSON.stringify(journal, null, 2));
  return { state: 'reconciled', versionId: config.versionId, commitSha: version.commitSha, sourceReconciliationRequired: false };
}
export async function applicationLifecycle(config, adapters = {}) {
  if (config.action === 'install') {
    const installed = await installRelease(config, adapters);
    if (installed.state !== 'installed') return installed;
    const publication = await provisionRestaurant({ ...config, intent: 'publish' }, adapters);
    return { ...installed, state: publication.deploymentState === 'succeeded' ? 'installed' : 'publishing', siteUrl: publication.siteUrl, projectId: publication.projectId, versionId: publication.savedVersionId, deploymentId: publication.deploymentId, pluginConnected: publication.pluginConnected };
  }
  if (config.action === 'publish') { await requireReconciledSources(config); return provisionRestaurant({ ...config, intent: 'publish' }, adapters); }
  if (config.action === 'restore') return restoreRelease(config, adapters);
  if (config.action === 'reconcile') return reconcileSources(config, adapters);
  throw new ProvisioningError('UNKNOWN_ACTION', 'Action d’application inconnue.');
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  let raw = ''; for await (const chunk of process.stdin) { raw += chunk; if (raw.length > 32768) throw new Error('Configuration trop grande.'); }
  try {
    const config = JSON.parse(raw);
    const gateway = async body => {
      const url = new URL('/v1/pegolotti/native-tools', config.baseUrl); if (url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)) throw new ProvisioningError('LOCAL_ONLY', 'Transport local requis.');
      const response = await fetch(url, { method: 'POST', headers: { authorization: `Bearer ${config.bearer}`, 'content-type': 'application/json' }, body: JSON.stringify(body), redirect: 'error', signal: AbortSignal.timeout(100000) });
      if (!response.ok) throw new ProvisioningError('NATIVE_FAILED', 'La restauration native doit être vérifiée.'); return response.json();
    };
    const result = await applicationLifecycle(config, { gateway }); process.stdout.write(JSON.stringify({ type: 'result', result }) + '\n');
  } catch (error) { process.stdout.write(JSON.stringify({ type: 'error', code: error.code || 'APPLICATION_FAILED', message: error instanceof ProvisioningError ? error.message : 'La modification de l’application n’est pas confirmée. Les sources sont conservées.' }) + '\n'); process.exitCode = 1; }
}
