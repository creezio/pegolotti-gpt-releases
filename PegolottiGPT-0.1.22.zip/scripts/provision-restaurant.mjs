import { randomUUID, createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { readFile, writeFile, rename, mkdir, lstat, readdir, cp } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const uuid = () => randomUUID().replaceAll('-', '');
const fingerprint = text => createHash('sha256').update(text).digest('hex');
const baselineReserved = part => /^\.(?:git|openai|pegolotti|wrangler)$|^node_modules$|^\.env(?:\.|$)/i.test(part) || /^(?:dist|build)$/i.test(part);
const sortedFiles = files => Object.entries(files).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0);
export class ProvisioningError extends Error { constructor(code, message, diagnostic) { super(message); this.code = code; if (diagnostic) this.diagnostic = diagnostic; } }
export async function captureTemplateBaseline(template) {
  const entries = []; let bytes = 0;
  const walk = async (directory, relative = '') => {
    if ((await lstat(directory)).isSymbolicLink()) throw new ProvisioningError('INVALID_TEMPLATE', 'Le socle livré ne doit pas contenir de lien ou jonction.');
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      if (baselineReserved(entry.name)) continue;
      const location = path.join(directory, entry.name), name = relative ? `${relative}/${entry.name}` : entry.name, info = await lstat(location);
      if (info.isSymbolicLink()) throw new ProvisioningError('INVALID_TEMPLATE', 'Le socle livré ne doit pas contenir de lien ou jonction.');
      if (info.isDirectory()) await walk(location, name);
      else {
        bytes += info.size;
        if (!info.isFile() || bytes > 64 * 1024 * 1024 || entries.length >= 2000) throw new ProvisioningError('INVALID_TEMPLATE', 'Le socle livré dépasse la taille ou le nombre de fichiers autorisé.');
        entries.push([name, fingerprint(await readFile(location))]);
      }
    }
  };
  await walk(path.resolve(template));
  const files = Object.fromEntries(entries);
  // Hash the trusted shipped template, never the potentially customized target.
  return { schemaVersion: 1, source: 'bundled-restaurant-template', files, fingerprint: fingerprint(JSON.stringify(sortedFiles(files))) };
}
export function unwrapNative(value) {
  let result = value?.ephemeralResult ?? value?.result ?? value;
  if (result?.structuredContent) result = result.structuredContent;
  if (result?.structuredContent) result = result.structuredContent;
  if (typeof result?.content === 'string') { try { return JSON.parse(result.content); } catch {} }
  if (Array.isArray(result?.content)) {
    const block = result.content.find(item => item.type === 'text' && /^\s*[{[]/.test(item.text));
    if (block) { try { return JSON.parse(block.text); } catch {} }
  }
  return result;
}
export function sourceCredential(value) {
  // create_site nests this object; the credential-refresh tool returns it
  // directly. Both are native responses, never a saved journal/token file.
  const credential = value?.source_repository_credential ?? value;
  if (credential?.auth_mode !== 'http_extra_header') throw new ProvisioningError('CREDENTIAL_REQUIRED', 'Le helper Sites installé demande un droit source HTTP compatible. Son mode d’authentification n’est pas disponible.');
  let remote; try { remote = new URL(credential.remote_url); } catch {}
  if (typeof credential.token !== 'string' || !credential.token || credential.token === '[not retained]' || /[\r\n\0]/.test(credential.token) || typeof credential.branch !== 'string' || !credential.branch || credential.branch.startsWith('-') || /[\r\n\0]/.test(credential.branch) || !remote || remote.protocol !== 'https:' || remote.username || remote.password || remote.search || remote.hash || credential.token_expires_at && (!Number.isFinite(Date.parse(credential.token_expires_at)) || Date.parse(credential.token_expires_at) <= Date.now())) throw new ProvisioningError('CREDENTIAL_REQUIRED', 'Le droit temporaire de synchronisation Sites est absent, expiré ou incompatible avec le helper officiel.');
  return credential;
}
async function safeDirectory(directory, parent) {
  const relative = path.relative(path.resolve(parent), path.resolve(directory));
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw new ProvisioningError('INVALID_DIRECTORY', 'Le dossier du Site doit être contenu dans le workspace du restaurant.');
  let current = path.resolve(parent);
  for (const part of relative.split(path.sep)) { current = path.join(current, part); try { if ((await lstat(current)).isSymbolicLink()) throw new ProvisioningError('INVALID_DIRECTORY', 'Les liens ne sont pas acceptés dans le workspace du Site.'); } catch (error) { if (error.code !== 'ENOENT') throw error; } }
}
export function sourceHelperDiagnostic(stderr, exitCode, signal) {
  // Classify only fixed, known helper/Git messages. No child output, path,
  // command, URL, environment value or credential leaves this function.
  const rules = [
    ['input', 'git-environment-override', /Run from the Site checkout without Git directory or index overrides\./],
    ['git', 'git-missing', /Unable to start Git\./],
    ['git', 'git-ownership', /detected dubious ownership|safe\.directory/i],
    ['git', 'git-tls', /SSL certificate|certificate verification|unable to get local issuer|schannel:/i],
    ['git', 'git-authentication', /Authentication failed|could not read Username|requested URL returned error: (?:401|403)/i],
    ['git', 'git-network', /Could not resolve host|Failed to connect|Connection timed out|Could not connect to server/i],
    ['checkout', 'remote-source-exists', /Existing remote source requires an empty checkout\./],
    ['checkout', 'source-reconciliation-required', /Local and remote Site history diverged|Remote Site source advanced while local edits are present|Reconcile remote changes|Git metadata is unreadable|Finish the existing Git merge/],
    ['checkout', 'git-root-mismatch', /Git must be rooted at the selected Site checkout|not a usable Git checkout/],
    ['checkout', 'git-url-rewrite', /The Site source URL is affected by Git URL rewriting/],
    ['checkout', 'source-project-mismatch', /source project_id does not match|Site source must contain a valid/],
    ['archive', 'archive-failed', /Sites packaging requires Node\.js and tar|Unable to package the Site archive|Site archive is missing|Missing dist\/server\/index\.js|Unable to prepare Sites build output/],
    ['build', 'build-failed', /Site preparation command failed\./],
    ['helper', 'helper-incompatible', /ERR_MODULE_NOT_FOUND|Cannot find module|SyntaxError:/],
  ];
  const match = rules.find(([, , expression]) => expression.test(stderr));
  return { stage: match?.[0] || 'helper', code: match?.[1] || 'helper-failed', exitCode: Number.isInteger(exitCode) ? exitCode : null, signal: /^(?:SIGINT|SIGHUP|SIGTERM|SIGKILL)$/.test(signal || '') ? signal : null };
}
export function sourceHelperEnvironment(environment, platform = process.platform) {
  const scoped = { ...environment };
  // External preload/debug options must not inject code into this credential-
  // carrying helper. Replace them only in its copied environment.
  const omitted = new Set(['NODE_OPTIONS', 'NODE_PATH', 'OPENAI_API_KEY', 'CODEX_ACCESS_TOKEN', 'CODEX_THREAD_ID', 'CODEX_APP_TOOLS_PIPE_PATH']);
  for (const name of Object.keys(scoped)) if (omitted.has(name.toUpperCase())) delete scoped[name];
  if (platform === 'win32') scoped.NODE_OPTIONS = `--import=${new URL('./windows-hidden-children.mjs', import.meta.url).href}`;
  return scoped;
}
export async function runSourceHelper({ pluginRoot, directory, projectId, credential, archivePath }) {
  credential = sourceCredential(credential);
  const helper = path.join(pluginRoot, 'scripts', 'site-workflow.mjs');
  const build = path.join(directory, 'scripts', 'build.mjs');
  if (process.platform === 'win32') {
    const preload = await lstat(fileURLToPath(new URL('./windows-hidden-children.mjs', import.meta.url)));
    if (!preload.isFile() || preload.isSymbolicLink()) throw new ProvisioningError('MISSING_TOOL', 'Le lanceur Windows du helper Sites doit être restauré depuis le paquet Pegolotti.');
  }
  const environment = sourceHelperEnvironment(process.env);
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [helper, '--project-id', projectId], { cwd: directory, env: environment, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    let output = '', diagnostics = '';
    // With pipe stdin the official helper reads JSON immediately. Its ready
    // prompt exists only for a TTY and is written to stderr, never stdout.
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify({ credential, commands: [[process.execPath, build]], archivePath }) + '\n');
    const timer = setTimeout(() => { child.kill(); reject(new ProvisioningError('SOURCE_TIMEOUT', 'Le résultat de préparation des sources est à vérifier avant reprise.')); }, 180000);
    child.stdout.on('data', chunk => {
      output += chunk.toString(); if (output.length > 4000000) output = output.slice(-2000000);
    });
    // Keep a bounded in-memory tail for fixed-code classification only. Never
    // forward or persist stderr, which can contain source URLs or credentials.
    child.stderr.on('data', chunk => { diagnostics = (diagnostics + chunk.toString()).slice(-65536); });
    child.on('error', () => { clearTimeout(timer); reject(new ProvisioningError('SOURCE_FAILED', 'Le helper Sites ne peut pas être démarré.', { stage: 'helper', code: 'helper-start-failed', exitCode: null, signal: null })); });
    child.on('close', (code, signal) => {
      clearTimeout(timer); if (code !== 0) {
        const diagnostic = sourceHelperDiagnostic(diagnostics, code, signal);
        return reject(new ProvisioningError('SOURCE_FAILED', `La préparation des sources Sites a échoué (${diagnostic.stage}/${diagnostic.code}, sortie ${diagnostic.exitCode ?? 'inconnue'}). Le checkout est conservé.`, diagnostic));
      }
      for (const line of output.trim().split(/\r?\n/).reverse()) { try { const result = JSON.parse(line); if (result.project_id === projectId && result.commit_sha && result.archive) return resolve(result); } catch {} }
      reject(new ProvisioningError('SOURCE_UNCONFIRMED', 'Le reçu des sources Sites est absent.'));
    });
  });
}
export async function provisionRestaurant(config, adapters = {}) {
  if (!config?.workspace || !config.sitesPluginRoot || !config.operationId || !/^[a-f0-9]{32}$/.test(config.operationId)) throw new ProvisioningError('CONFIG_REQUIRED', 'Workspace, helper Sites et identifiant d’opération sont requis.');
  const directory = path.join(config.workspace, 'pegolotti-site'); await safeDirectory(directory, config.workspace);
  const journalDirectory = path.join(config.workspace, '.pegolotti'); await mkdir(journalDirectory, { recursive: true });
  const journalPath = path.join(journalDirectory, 'provision.json');
  let state; try { state = JSON.parse(await readFile(journalPath, 'utf8')); } catch (error) { if (error.code !== 'ENOENT') throw error; state = { schema: 1, operationId: config.operationId, state: 'starting', steps: [] }; }
  if (config.intent === 'publish' && state.sourceReconciliationRequired) throw new ProvisioningError('SOURCE_RECONCILIATION_REQUIRED', 'La version restaurée doit être réconciliée avec les sources avant une nouvelle publication.');
  if (state.operationId !== config.operationId && !['ready', 'connection-required'].includes(state.state)) throw new ProvisioningError('OPERATION_EXISTS', 'Reprenez l’installation existante avant d’en commencer une autre.');
  if (config.intent === 'publish' && state.publishOperationId !== config.operationId) {
    if (!state.projectId || !state.deploymentId || state.deploymentState !== 'succeeded') throw new ProvisioningError('SITE_REQUIRED', 'Le Site initial doit être publié avant une évolution.');
    state.publishOperationId = config.operationId; state.operationId = config.operationId;
    state.previousDeploymentId = state.deploymentId; state.previousSavedVersionId = state.savedVersionId;
    state.deploymentId = null; state.savedVersionId = null; state.deploymentState = null;
  }
  const save = async () => { const temporary = journalPath + '.tmp'; await writeFile(temporary, JSON.stringify(state, null, 2), { mode: 0o600 }); await rename(temporary, journalPath); adapters.progress?.(state); };
  if (state.deploymentState === 'failed') { state.previousFailedDeploymentId = state.deploymentId; state.deploymentId = null; state.deploymentState = null; state.deploymentAttempt = (state.deploymentAttempt || 0) + 1; await save(); }
  const gateway = adapters.gateway || (async body => {
    const endpoint = new URL('/v1/pegolotti/native-tools', config.baseUrl);
    if (!['127.0.0.1', 'localhost', '[::1]'].includes(endpoint.hostname) || endpoint.protocol !== 'http:') throw new ProvisioningError('LOCAL_ONLY', 'Le helper utilise uniquement le gateway local.');
    const response = await fetch(endpoint, { method: 'POST', headers: { authorization: `Bearer ${config.bearer}`, 'content-type': 'application/json' }, body: JSON.stringify(body), redirect: 'error', signal: AbortSignal.timeout(100000) });
    const result = await response.json(); if (!response.ok) throw new ProvisioningError(response.status === 409 ? 'UNCERTAIN' : 'NATIVE_FAILED', 'L’opération native doit être vérifiée dans le harness.'); return result;
  });
  const inventoryResult = unwrapNative(await gateway({ operation: 'list' }));
  const inventory = inventoryResult?.tools || [];
  const resolveTool = suffix => { const tool = inventory.find(row => (row.name || row.Name)?.endsWith(`.${suffix}`)); if (!tool) throw new ProvisioningError('MISSING_TOOL', `L’outil Sites ${suffix} n’est pas disponible dans ce compte.`); return { server: tool.server || tool.Server, tool: tool.name || tool.Name }; };
  const call = async (suffix, args, id = uuid()) => unwrapNative(await gateway({ operation: 'call', ...resolveTool(suffix), id, arguments: args, ...(config.threadId ? { threadId: config.threadId } : {}) }));
  let credential;
  if (!state.projectId) {
    state.creationId ||= fingerprint(`${config.operationId}:create`).slice(0, 32); state.state = 'creating-site'; await save();
    const created = await call('create_site', { creation_intent: 'user_requested', slug: `pegolotti-${(config.restaurantId || config.operationId).replace(/[^a-z0-9]/gi, '').slice(0, 20).toLowerCase()}`, title: config.restaurantName || 'Mon Pegolotti', description: 'Socle personnel Pegolotti. L’application métier sera installée lorsqu’elle sera disponible.' }, state.creationId);
    if (!created?.id) throw new ProvisioningError('SITE_UNCONFIRMED', 'La création du Site ne dispose pas d’un reçu vérifiable.');
    state.projectId = created.id; state.expectedUrl = created.expected_url; state.steps.push({ id: 'site-created', state: 'ready' }); credential = created.source_repository_credential; await save();
  }
  if (!state.deploymentId) {
    state.state = 'preparing-source'; await save();
    await mkdir(directory, { recursive: true });
    if (!state.sourcePrepared) {
      const template = config.templateDirectory || fileURLToPath(new URL('../templates/restaurant/', import.meta.url));
      const baseline = await captureTemplateBaseline(template);
      if (state.templateBaseline && state.templateBaseline.fingerprint !== baseline.fingerprint) throw new ProvisioningError('TEMPLATE_CHANGED', 'Le socle livré a changé pendant sa copie. Vérifiez les sources avant de reprendre.');
      if (!state.templateBaseline) { state.templateBaseline = baseline; await save(); }
      await cp(template, directory, { recursive: true, errorOnExist: false, force: false, dereference: false });
      await mkdir(path.join(directory, '.openai'), { recursive: true });
      await writeFile(path.join(directory, '.openai', 'hosting.json'), JSON.stringify({ project_id: state.projectId, d1: null, r2: null, capabilities: ['mcp'] }, null, 2));
      state.sourcePrepared = true; await save();
    }
    let source;
    if (!state.savedVersionId) {
      // A retained create_site receipt may contain a redacted/expired token.
      // Renew only the credential for its already persisted exact Site ID.
      if (credential) { try { credential = sourceCredential(credential); } catch { credential = null; } }
      credential ||= sourceCredential(await call('create_source_repository_write_credential', { project_id: state.projectId }));
      const archivePath = path.join(config.workspace, '.pegolotti', 'restaurant-site.tar.gz');
      source = await (adapters.sourceHelper || runSourceHelper)({ pluginRoot: config.sitesPluginRoot, directory, projectId: state.projectId, credential, archivePath });
      credential = null; state.commitSha = source.commit_sha;
    }
    state.state = 'publishing'; await save();
    const published = state.savedVersionId ? await call('deploy_private_site_version', { project_id: state.projectId, version_id: state.savedVersionId }, fingerprint(`${state.projectId}:${state.savedVersionId}:deploy:${state.deploymentAttempt || 0}`).slice(0, 32)) : await call('save_version_and_deploy_private', { project_id: state.projectId, commit_sha: state.commitSha, archive: source.archive }, fingerprint(`${state.projectId}:${state.commitSha}:publish`).slice(0, 32));
    state.savedVersionId = published.version_id || published.saved_version_id || published.error_data?.saved_version_id || state.savedVersionId;
    state.versions ||= []; if (state.savedVersionId && !state.versions.some(version => version.id === state.savedVersionId)) state.versions.push({ id: state.savedVersionId, commitSha: state.commitSha, createdAt: new Date().toISOString() });
    await save();
    if (!published.id) throw new ProvisioningError(state.savedVersionId ? 'SAVED_VERSION_PENDING' : 'DEPLOYMENT_UNCONFIRMED', state.savedVersionId ? 'La version a été sauvegardée ; reprenez son déploiement.' : 'Le reçu de déploiement est absent.');
    state.deploymentId = published.id; state.deploymentState = published.status; state.siteUrl = published.url || state.expectedUrl; await save();
  }
  for (let attempt = 0; !['succeeded', 'failed'].includes(state.deploymentState) && attempt < 30; attempt++) {
    await (adapters.delay || (ms => new Promise(resolve => setTimeout(resolve, ms))))(2000);
    const deployment = await call('get_deployment_status', { project_id: state.projectId, deployment_id: state.deploymentId });
    state.deploymentState = deployment.status; state.siteUrl = deployment.url || state.siteUrl; await save();
  }
  if (state.deploymentState !== 'succeeded') { state.state = state.deploymentState === 'failed' ? 'failed' : 'publishing'; await save(); throw new ProvisioningError(state.deploymentState === 'failed' ? 'DEPLOYMENT_FAILED' : 'PUBLISH_PENDING', state.deploymentState === 'failed' ? 'Le déploiement a échoué ; sa version sauvegardée peut être redéployée.' : 'Le déploiement est encore en cours. Reprenez le suivi de cette opération.'); }
  const site = await call('get_site', { project_id: state.projectId, include_mcp_connection: true });
  state.pluginId = site.mcp_connection?.plugin_id || null; state.siteUrl = site.current_live_url || state.siteUrl;
  state.steps = [{ id: 'site', state: 'ready' }, { id: 'publication', state: 'ready' }, { id: 'plugin-created', state: state.pluginId ? 'ready' : 'pending' }];
  let observation; if (state.pluginId) { try { observation = unwrapNative(await gateway({ operation: 'plugin-status', pluginId: state.pluginId })); } catch {} }
  if (state.pluginId && observation?.installed !== true && config.autoInstallPlugin !== false) {
    const admission = { operation: 'plugin-install', pluginId: state.pluginId, id: fingerprint(`${state.projectId}:${state.pluginId}:install`).slice(0, 32) };
    try {
      let installation = unwrapNative(await gateway(admission));
      for (let attempt = 0; installation.state === 'installing' && attempt < 30; attempt++) { await (adapters.delay || (ms => new Promise(resolve => setTimeout(resolve, ms))))(2000); installation = unwrapNative(await gateway(admission)); }
      state.pluginInstallationState = installation.state;
      state.pluginInstallationDetail = installation.detail || installation.error || null;
      observation = unwrapNative(await gateway({ operation: 'plugin-status', pluginId: state.pluginId }));
    } catch { state.pluginInstallationState = 'unverified'; }
  }
  state.pluginInstalled = observation?.installed === true; state.pluginConnected = observation?.connected === true;
  state.pluginInstallUrl = observation?.installUrl || null;
  state.state = state.pluginInstalled && state.pluginConnected ? 'ready' : 'connection-required'; await save(); return state;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  let input = ''; for await (const chunk of process.stdin) { input += chunk; if (input.length > 32768) throw new Error('Configuration trop grande.'); }
  try { const result = await provisionRestaurant(JSON.parse(input), { progress: state => process.stdout.write(JSON.stringify({ type: 'progress', state: state.state, projectId: state.projectId, siteUrl: state.siteUrl }) + '\n') }); process.stdout.write(JSON.stringify({ type: 'result', result }) + '\n'); }
  catch (error) { process.stdout.write(JSON.stringify({ type: 'error', code: error.code || 'PROVISION_FAILED', message: error instanceof ProvisioningError ? error.message : 'Installation interrompue. Les reçus existants sont conservés.', ...(error instanceof ProvisioningError && error.diagnostic ? { diagnostic: error.diagnostic } : {}) }) + '\n'); process.exitCode = 1; }
}
